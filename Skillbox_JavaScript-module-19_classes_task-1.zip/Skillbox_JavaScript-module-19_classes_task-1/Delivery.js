export class Delivery {
    constructor(name, address, distance) {
      this._name = name;
      this._address = address;
      this._distance = distance;
    }

    get name() {
      return this._name;
    }

    set name(newName) {
      this._name = newName;
    }

    get address() {
      return this._address;
    }

    set address(newAddress) {
      this._address = newAddress;
    }

    get distance() {
      return this._distance;
    }

    set distance(newDistance) {
      this._distance = newDistance;
    }

    createCardElement() {
      const card = document.createElement("div");
      card.className = "delivery-card";

      card.innerHTML = `
        <p>Имя:</p>
        <span>${this._name}</span>
        <p>Адрес:</p>
        <span>${this._address}</span>
        <p>Расстояние:</p>
        <span>${this._distance} км</span>
      `;

      return card;
    }
  }
